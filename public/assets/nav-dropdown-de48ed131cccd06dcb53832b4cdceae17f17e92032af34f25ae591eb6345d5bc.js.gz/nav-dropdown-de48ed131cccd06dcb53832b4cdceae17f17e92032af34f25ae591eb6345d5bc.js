$(document).ready(function(){
	$('.dropdown').dropdown({
	    // you can use any ui transition
	    transition: 'drop'
	});
});
